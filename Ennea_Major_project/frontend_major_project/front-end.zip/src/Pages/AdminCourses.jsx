import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import styled from "styled-components";
import { Button, Table, Modal, Form, Input, message, Popconfirm } from "antd";

// Styled Components
const AdminContainer = styled.div`
  max-width: 1200px;
  margin: 2rem auto;
  padding: 1rem;
  background: #f0f2f5;
  border-radius: 8px;
`;

const Header = styled.h2`
  text-align: center;
  margin-bottom: 1.5rem;
`;

// Fetch all courses from the backend
const fetchCourses = async () => {
  const response = await fetch("http://localhost:8080/courses/fetchcourses", {
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
  });
  if (!response.ok) {
    throw new Error("Failed to fetch courses.");
  }
  return response.json();
};

// Add a new course
const addCourse = async (course) => {
  const response = await fetch("http://localhost:8080/courses/addCourse", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
    body: JSON.stringify(course),
  });
  if (!response.ok) {
    const errorData = await response.json(); // Log error details
    console.error(errorData);
    throw new Error("Failed to add course.");
  }
};

// Edit an existing course
const editCourse = async ({ id, course }) => {
  const response = await fetch(`http://localhost:8080/courses/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
    body: JSON.stringify(course),
  });
  if (!response.ok) {
    throw new Error("Failed to edit course.");
  }
};

// Delete a course
const deleteCourse = async (id) => {
  const response = await fetch(`http://localhost:8080/courses/deleteCourse/${id}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
  });
  if (!response.ok) {
    throw new Error("Failed to delete course.");
  }
};

const AdminCourses = () => {
  const queryClient = useQueryClient();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);

  // Fetch all courses
  const { data: courses, isLoading } = useQuery({
    queryKey: ["courses"],
    queryFn: fetchCourses,
    onError: () => {
      message.error("Failed to fetch courses.");
    },
  });

  // Add Course Mutation
  const { mutate: addNewCourse } = useMutation({
    mutationFn: addCourse,
    onSuccess: () => {
      message.success("Course added successfully.");
      queryClient.invalidateQueries(["courses"]);
      setIsModalOpen(false);
    },
    onError: () => {
      message.error("Failed to add course.");
    },
  });

  // Edit Course Mutation
  const { mutate: updateCourse } = useMutation({
    mutationFn: editCourse,
    onSuccess: () => {
      message.success("Course updated successfully.");
      queryClient.invalidateQueries(["courses"]);
      setIsModalOpen(false);
    },
    onError: () => {
      message.error("Failed to update course.");
    },
  });

  // Delete Course Mutation
  const { mutate: removeCourse } = useMutation({
    mutationFn: deleteCourse,
    onSuccess: () => {
      message.success("Course deleted successfully.");
      queryClient.invalidateQueries(["courses"]);
    },
    onError: () => {
      message.error("Failed to delete course.");
    },
  });

  // Form Submit Handler
  const handleFormSubmit = (values) => {
    if (editingCourse) {
      updateCourse({ id: editingCourse.id, course: values });
    } else {
      addNewCourse(values);
    }
  };

  if (isLoading) {
    return <p>Loading courses...</p>;
  }

  return (
    <AdminContainer>
      <Header>Admin - Manage Courses</Header>

      {/* Add/Edit Course Modal */}
      <Modal
        title={editingCourse ? "Edit Course" : "Add Course"}
        open={isModalOpen}
        onCancel={() => {
          setIsModalOpen(false);
          setEditingCourse(null);
        }}
        footer={null}
      >
        <Form
  layout="vertical"
  onFinish={handleFormSubmit}
  initialValues={editingCourse || {
    id: "",
    title: "",
    shortIntro: "",
    category: "",
    subCategory: "",
    courseType: "",
    language: "",
    subtitleLanguages: "",
    skills: "",
    instructors: "",
    duration: "",
  }}
>
    <Form.Item
    name="id"
    label="Course id"
    rules={[{ required: true, message: "Please enter the course title." }]}
  >
    <Input />
  </Form.Item>
  <Form.Item
    name="title"
    label="Course Title"
    rules={[{ required: true, message: "Please enter the course title." }]}
  >
    <Input />
  </Form.Item>
  <Form.Item
    name="shortIntro"
    label="Short Introduction"
    rules={[{ required: false }]}
  >
    <Input.TextArea />
  </Form.Item>
  <Form.Item
    name="category"
    label="Course Category"
    rules={[{ required: true, message: "Please enter the course category." }]}
  >
    <Input />
  </Form.Item>
  <Form.Item
    name="subCategory"
    label="Sub-Category"
    rules={[{ required: false }]}
  >
    <Input />
  </Form.Item>
  <Form.Item
    name="courseType"
    label="Course Type"
    rules={[{ required: false }]}
  >
    <Input />
  </Form.Item>
  <Form.Item
    name="language"
    label="Language"
    rules={[{ required: false }]}
  >
    <Input />
  </Form.Item>
  <Form.Item
    name="subtitleLanguages"
    label="Subtitle Languages"
    rules={[{ required: false }]}
  >
    <Input />
  </Form.Item>
  <Form.Item
    name="skills"
    label="Skills"
    rules={[{ required: false }]}
  >
    <Input.TextArea />
  </Form.Item>
  <Form.Item
    name="instructors"
    label="Instructors"
    rules={[{ required: false }]}
  >
    <Input />
  </Form.Item>
  <Form.Item
    name="duration"
    label="Duration"
    rules={[{ required: false }]}
  >
    <Input />
  </Form.Item>
  <Button type="primary" htmlType="submit" block>
    {editingCourse ? "Update Course" : "Add Course"}
  </Button>
</Form>
      </Modal>

      {/* Course Table */}
      <Table
        dataSource={courses}
        rowKey="id"
        columns={[
            {
                title: "ID",
                dataIndex: "id",
                key: "id",
              },
              {
                title: "Course Title",
                dataIndex: "title",
                key: "title",
              },
              {
                title: "Category",
                dataIndex: "category",
                key: "category",
              },
              {
                title: "Sub-Category",
                dataIndex: "subCategory",
                key: "subCategory",
              },
              {
                title: "Course Type",
                dataIndex: "courseType",
                key: "courseType",
              },
              {
                title: "Language",
                dataIndex: "language",
                key: "language",
              },
              {
                title: "Instructors",
                dataIndex: "instructors",
                key: "instructors",
              },
              {
                title: "Duration",
                dataIndex: "duration",
                key: "duration",
              },
              {
                title: "Students Enrolled",
                dataIndex: "studentsEnrolled",
                key: "studentsEnrolled",
                render: (count) => count || 0,
              },
          {
            title: "Actions",
            key: "actions",
            render: (_, course) => (
              <>
                <Button
                  type="link"
                  onClick={() => {
                    setEditingCourse(course);
                    setIsModalOpen(true);
                  }}
                >
                  Edit
                </Button>
                <Popconfirm
                  title="Are you sure you want to delete this course?"
                  onConfirm={() => removeCourse(course.id)}
                  okText="Yes"
                  cancelText="No"
                >
                  <Button type="link" danger>
                    Delete
                  </Button>
                </Popconfirm>
              </>
            ),
          },
        ]}
      />

      {/* Add Course Button */}
      <Button
        type="primary"
        style={{ marginTop: "1rem" }}
        onClick={() => {
          setEditingCourse(null);
          setIsModalOpen(true);
        }}
      >
        Add Course
      </Button>
    </AdminContainer>
  );
};

export default AdminCourses;
