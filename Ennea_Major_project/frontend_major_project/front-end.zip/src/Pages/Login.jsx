import React from 'react';
import { Button, Form, Input, message } from 'antd';
import { useLocation } from 'react-router-dom';

function Login() {
  const loc = useLocation();
  const ndata = loc.state?.data || {}; // Use optional chaining and fallback to an empty object

  const onFinish = async (values) => {
    try {
      const response = await fetch('http://localhost:8080/user/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });

      if (!response.ok) {
        throw new Error('Login failed. Please check your credentials.');
      }

      const data = await response.text(); // Parse the response as text
      if (data.includes('.') && data.split('.').length === 3) {
        // Check if the response looks like a JWT token (3 parts separated by dots)
        localStorage.setItem('token', data);
        console.log(data)
        message.success('Login successful!');
      } else {
        // Otherwise, treat it as an error message
        throw new Error(data);
      }
    } catch (error) {
      message.error(error.message);
    }
  };

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <Form
      name="basic"
      labelCol={{
        span: 8,
      }}
      wrapperCol={{
        span: 16,
      }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      autoComplete="off"
      initialValues={{
        email: ndata.email || '', // Provided fallback value
        password: ndata.password || '', // Provided fallback value
      }}
    >
      <Form.Item
        label="Email"
        name="email"
        rules={[
          {
            required: true,
            message: 'Please input your Email!',
          },
        ]}
      >
        <Input />
      </Form.Item>

      <Form.Item
        label="Password"
        name="password"
        rules={[
          {
            required: true,
            message: 'Please input your password!',
          },
        ]}
      >
        <Input.Password />
      </Form.Item>

      <Form.Item
        wrapperCol={{
          offset: 8,
          span: 16,
        }}
      >
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
  );
}

export default Login;


