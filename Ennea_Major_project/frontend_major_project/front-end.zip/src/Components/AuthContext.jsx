import React, { createContext, useState, useEffect } from 'react';
import {jwtDecode} from 'jwt-decode';

// Create Auth Context
const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [role, setRole] = useState(null);
  const [isExpired, setIsExpired] = useState(true);

  useEffect(() => {
    if (token) {
      try {
        const decoded = jwtDecode(token);
        setRole(decoded.role);
        setIsExpired(Date.now() >= decoded.exp * 1000);
      } catch (err) {
        console.error('Invalid token', err);
        setRole(null);
        setIsExpired(true);
      }
    } else {
      setRole(null);
      setIsExpired(true);
    }
  }, [token]);

  const logout = () => {
    setToken(null);
    localStorage.removeItem('token');
    setRole(null);
    setIsExpired(true);
  };

  return (
    <AuthContext.Provider value={{ token, role, isExpired, setToken, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
