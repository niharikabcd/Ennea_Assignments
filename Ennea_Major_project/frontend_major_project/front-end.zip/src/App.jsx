import './App.css'
function App() {

  return (
    <>
      <h1>Welcome to Tech Courses</h1>
    </>
  )
}

export default App
